import React from 'react'

const Services = () => {
  return (
    <h1 id='services'>Services</h1>
  )
}

export default Services