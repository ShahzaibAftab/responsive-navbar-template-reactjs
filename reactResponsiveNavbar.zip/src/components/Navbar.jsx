
// 1) Develope whole navbar with close and Burger toggle 2) Use media Queries to remove/Add on smaller
// and wider screens such that at wider screen Whole Navbar appear with logo and other page buttons 
// while at smaller screen only Burger and active buttons Appear vertically 3) Apply UseState hook 
// for close button and hamburger with styled classnames
import React,{useState} from 'react'
import './Navbar.css'
import {AiFillCloseCircle} from 'react-icons/ai'
import {GiHamburgerMenu} from 'react-icons/gi'
const Navbar = () => {
    const [active,setActive]=useState('navbar');// 3.1
    const showMenu=()=>
    {
        if(active==='navbar')
        {
            setActive('navbar displayMenu')
        }
        else
        {
            setActive('navbar')
        }
    }
    const removeMenu=()=>
    {
            setActive('navbar')
    }
  return (
   <header className="header">
    <div className="logoDiv">
        <h2>Shahzaib</h2>
    </div>
    <div className={active}>
        <ul onClick={removeMenu} className="navMenu">
            <li className="navItem">
                <a href="#Home" className="navLink">Home</a>
            </li>
            <li className="navItem">
                <a href="#about" className="navLink">About</a>
            </li>
            <li className="navItem">
                <a href="#services" className="navLink">Services</a>
            </li>
            <li className="navItem">
                <a href="#contact" className="navLink">Contact</a>
            </li>
        </ul>
        <div onClick={removeMenu} className="closeNavbarIcon">
            <AiFillCloseCircle className='icon'/>
        </div>
    </div>
         <div onClick={showMenu} className="toggleNavbarIcon">
        <GiHamburgerMenu className='icon'/>
        </div>
   </header>
  )
}

export default Navbar