import React from 'react'

const About = () => {
  return (
    <h1 id='about'>About</h1>
  )
}

export default About