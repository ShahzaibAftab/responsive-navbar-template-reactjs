
import React from 'react'
import './App.css'
import About from './components/About';
import Contact from './components/Contact';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Services from './components/Services';
const App = () => {
  return (
    <>
 <Navbar/>
 <Home/>
 <About/>
 <Contact/>
 <Services/> 
 </>
  )
}

export default App