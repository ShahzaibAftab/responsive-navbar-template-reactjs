import React from 'react'

const Home = () => {
  return (
    <h1 id='home'>Home</h1>
  )
}

export default Home